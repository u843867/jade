<?php return array (
  'hello-world' => 'App\\Http\\Livewire\\HelloWorld',
  'payment-authorisation' => 'App\\Http\\Livewire\\PaymentAuthorisation',
  'payment-initialise' => 'App\\Http\\Livewire\\PaymentInitialise',
  'payment-intent-confirm' => 'App\\Http\\Livewire\\PaymentIntentConfirm',
  'payment-route' => 'App\\Http\\Livewire\\PaymentRoute',
  'stripe-payment-intent' => 'App\\Http\\Livewire\\StripePaymentIntent',
);