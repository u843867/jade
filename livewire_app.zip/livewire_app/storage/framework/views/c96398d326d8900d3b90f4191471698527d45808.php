<div>

    <input wire:model="name" type="text">
    
    Hello <?php echo e($name); ?>


</div>
<?php /**PATH D:\xampp\htdocs\jade\livewire_app\resources\views/livewire/hello-world.blade.php ENDPATH**/ ?>