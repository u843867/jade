

<?php $__env->startSection('content'); ?>
    

    
    <!-- these are the components - start -->
    <!-- <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hello-world', ['name' => 'Justin'])->html();
} elseif ($_instance->childHasBeenRendered('Lj77cIB')) {
    $componentId = $_instance->getRenderedChildComponentId('Lj77cIB');
    $componentTag = $_instance->getRenderedChildComponentTagName('Lj77cIB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Lj77cIB');
} else {
    $response = \Livewire\Livewire::mount('hello-world', ['name' => 'Justin']);
    $html = $response->html();
    $_instance->logRenderedChild('Lj77cIB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> -->

    <div class="flex mx-10 my-5 flex-center position-ref full-height">
        
        <div class="w-1/3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-initialise')->html();
} elseif ($_instance->childHasBeenRendered('UrVjia9')) {
    $componentId = $_instance->getRenderedChildComponentId('UrVjia9');
    $componentTag = $_instance->getRenderedChildComponentTagName('UrVjia9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UrVjia9');
} else {
    $response = \Livewire\Livewire::mount('payment-initialise');
    $html = $response->html();
    $_instance->logRenderedChild('UrVjia9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>


        <div class="w-1/3">
             <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-route')->html();
} elseif ($_instance->childHasBeenRendered('FXiROeq')) {
    $componentId = $_instance->getRenderedChildComponentId('FXiROeq');
    $componentTag = $_instance->getRenderedChildComponentTagName('FXiROeq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FXiROeq');
} else {
    $response = \Livewire\Livewire::mount('payment-route');
    $html = $response->html();
    $_instance->logRenderedChild('FXiROeq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
        </div>


        <div class="w-1/3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-authorisation')->html();
} elseif ($_instance->childHasBeenRendered('JKjHe6g')) {
    $componentId = $_instance->getRenderedChildComponentId('JKjHe6g');
    $componentTag = $_instance->getRenderedChildComponentTagName('JKjHe6g');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JKjHe6g');
} else {
    $response = \Livewire\Livewire::mount('payment-authorisation');
    $html = $response->html();
    $_instance->logRenderedChild('JKjHe6g', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
        </div>
    </div>


    <!-- these are the components - end -->

    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\jade\livewire_app\resources\views/welcomen.blade.php ENDPATH**/ ?>