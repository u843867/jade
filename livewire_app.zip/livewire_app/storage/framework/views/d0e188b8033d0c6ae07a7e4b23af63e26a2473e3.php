

<?php $__env->startSection('content'); ?>
    

    
    <!-- these are the components - start -->
    <!-- <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hello-world', ['name' => 'Justin'])->html();
} elseif ($_instance->childHasBeenRendered('wLaOxW7')) {
    $componentId = $_instance->getRenderedChildComponentId('wLaOxW7');
    $componentTag = $_instance->getRenderedChildComponentTagName('wLaOxW7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wLaOxW7');
} else {
    $response = \Livewire\Livewire::mount('hello-world', ['name' => 'Justin']);
    $html = $response->html();
    $_instance->logRenderedChild('wLaOxW7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> -->

    <div class="flex mx-10 my-5 flex-center position-ref full-height">
        
        <div class="w-1/3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('stripe-payment-intent')->html();
} elseif ($_instance->childHasBeenRendered('3vI6OUf')) {
    $componentId = $_instance->getRenderedChildComponentId('3vI6OUf');
    $componentTag = $_instance->getRenderedChildComponentTagName('3vI6OUf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3vI6OUf');
} else {
    $response = \Livewire\Livewire::mount('stripe-payment-intent');
    $html = $response->html();
    $_instance->logRenderedChild('3vI6OUf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>


        <div class="w-1/3">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-intent-confirm')->html();
} elseif ($_instance->childHasBeenRendered('mtwBwF4')) {
    $componentId = $_instance->getRenderedChildComponentId('mtwBwF4');
    $componentTag = $_instance->getRenderedChildComponentTagName('mtwBwF4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mtwBwF4');
} else {
    $response = \Livewire\Livewire::mount('payment-intent-confirm');
    $html = $response->html();
    $_instance->logRenderedChild('mtwBwF4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>


        <div class="w-1/3">
    
        </div>
    </div>


    <!-- these are the components - end -->

    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout-stripe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\jade\livewire_app\resources\views/stripe.blade.php ENDPATH**/ ?>