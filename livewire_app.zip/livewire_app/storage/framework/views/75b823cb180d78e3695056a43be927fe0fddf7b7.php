<html>
    <head>

        <title>Laravel</title>
      
        <?php echo \Livewire\Livewire::styles(); ?>

        
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"
    </head>

    <body>

        <p class="text-xl">I'm a paragraphsda</p>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hello-world', ['name' => 'Jkustin'])->html();
} elseif ($_instance->childHasBeenRendered('PTGM5oY')) {
    $componentId = $_instance->getRenderedChildComponentId('PTGM5oY');
    $componentTag = $_instance->getRenderedChildComponentTagName('PTGM5oY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PTGM5oY');
} else {
    $response = \Livewire\Livewire::mount('hello-world', ['name' => 'Jkustin']);
    $html = $response->html();
    $_instance->logRenderedChild('PTGM5oY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        
        <?php echo \Livewire\Livewire::scripts(); ?>


    </body>

</html>
<?php /**PATH D:\xampp\htdocs\jade\livewire_app\resources\views/welcome.blade.php ENDPATH**/ ?>