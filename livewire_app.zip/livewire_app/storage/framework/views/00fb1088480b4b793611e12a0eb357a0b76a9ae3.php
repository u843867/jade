<html>
    <head>

        <title>Laravel</title>
      
        <?php echo \Livewire\Livewire::styles(); ?>

        
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"
    </head>

    <body>

        <p class="text-xl">I'm a paragraph</p>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hello-world', ['name' => 'Jkustin'])->html();
} elseif ($_instance->childHasBeenRendered('qEpdvxn')) {
    $componentId = $_instance->getRenderedChildComponentId('qEpdvxn');
    $componentTag = $_instance->getRenderedChildComponentTagName('qEpdvxn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qEpdvxn');
} else {
    $response = \Livewire\Livewire::mount('hello-world', ['name' => 'Jkustin']);
    $html = $response->html();
    $_instance->logRenderedChild('qEpdvxn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        
        <?php echo \Livewire\Livewire::scripts(); ?>


    </body>

</html>
<?php /**PATH D:\xampp\htdocs\jade\livewire\resources\views/welcome.blade.php ENDPATH**/ ?>