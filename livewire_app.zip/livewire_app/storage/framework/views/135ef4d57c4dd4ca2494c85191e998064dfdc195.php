<div>

    <input wire:model="name" type="text">
    
    Hello <?php echo e($name); ?>


</div>
<?php /**PATH D:\xampp\htdocs\jade\livewire\resources\views/livewire/hello-world.blade.php ENDPATH**/ ?>