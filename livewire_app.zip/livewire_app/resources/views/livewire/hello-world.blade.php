<div>

    <input wire:model="name" type="text">
    
    Hello {{ $name }}

</div>
