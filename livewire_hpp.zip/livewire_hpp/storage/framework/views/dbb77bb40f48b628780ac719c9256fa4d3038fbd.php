

<?php $__env->startSection('content'); ?>
    

    
    <!-- these are the components - start -->
    <!-- <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hello-world', ['name' => 'Justin'])->html();
} elseif ($_instance->childHasBeenRendered('kIPnwkz')) {
    $componentId = $_instance->getRenderedChildComponentId('kIPnwkz');
    $componentTag = $_instance->getRenderedChildComponentTagName('kIPnwkz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kIPnwkz');
} else {
    $response = \Livewire\Livewire::mount('hello-world', ['name' => 'Justin']);
    $html = $response->html();
    $_instance->logRenderedChild('kIPnwkz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> -->

    <div class="flex mx-10 my-5 flex-center position-ref full-height">
        
        <div class="w-1/3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-initialise')->html();
} elseif ($_instance->childHasBeenRendered('IiQJVgQ')) {
    $componentId = $_instance->getRenderedChildComponentId('IiQJVgQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('IiQJVgQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IiQJVgQ');
} else {
    $response = \Livewire\Livewire::mount('payment-initialise');
    $html = $response->html();
    $_instance->logRenderedChild('IiQJVgQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>


        <div class="w-1/3">
             <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-route')->html();
} elseif ($_instance->childHasBeenRendered('4bV6MAr')) {
    $componentId = $_instance->getRenderedChildComponentId('4bV6MAr');
    $componentTag = $_instance->getRenderedChildComponentTagName('4bV6MAr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4bV6MAr');
} else {
    $response = \Livewire\Livewire::mount('payment-route');
    $html = $response->html();
    $_instance->logRenderedChild('4bV6MAr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
        </div>


        <div class="w-1/3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-authorisation')->html();
} elseif ($_instance->childHasBeenRendered('na4DMfL')) {
    $componentId = $_instance->getRenderedChildComponentId('na4DMfL');
    $componentTag = $_instance->getRenderedChildComponentTagName('na4DMfL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('na4DMfL');
} else {
    $response = \Livewire\Livewire::mount('payment-authorisation');
    $html = $response->html();
    $_instance->logRenderedChild('na4DMfL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>  
        </div>
    </div>


    <!-- these are the components - end -->

    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\jade\livewire_hpp\resources\views/welcomen.blade.php ENDPATH**/ ?>