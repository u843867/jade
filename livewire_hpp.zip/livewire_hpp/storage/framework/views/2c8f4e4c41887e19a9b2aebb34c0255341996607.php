<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Order</title>

    <!-- Fonts -->
    <!-- <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet"> -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <link href="<?php echo e(asset('css/myCss.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <script src="https://kit.fontawesome.com/ed601ea99b.js" crossorigin="anonymous"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/myJs.js')); ?>" />
    </script>

    <?php echo \Livewire\Livewire::styles(); ?>


</head>

<body x-data="{ 'open_modal': false }" @keydown.escape="open_modal = false" x-cloak class="h-full bg-gray-100">

    <div class="flex flex-col h-screen">


        <header>

            <nav class="flex flex-wrap items-center justify-between px-2 py-3 bg-blue-900">

                <div class="flex flex-shrink-0 px-2 text-white ">
                    
                    <div class="flex items-center px-1 py-1">
                        <h1 class="text-xl font-semibold tracking-tight">Order Management</h1>
                    </div>

                </div>

            </nav>

        </header>


        <?php echo $__env->yieldContent('main-content'); ?>


    </div>


    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.7.3/dist/alpine.min.js" defer></script>

    <?php echo \Livewire\Livewire::scripts(); ?>


</body>

</html><?php /**PATH D:\xampp\htdocs\jade\livewire_hpp\resources\views/layout-order.blade.php ENDPATH**/ ?>