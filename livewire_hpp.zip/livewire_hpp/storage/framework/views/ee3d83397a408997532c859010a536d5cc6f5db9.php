

<?php $__env->startSection('content'); ?>
    

    
    <!-- these are the components - start -->
    <!-- <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hello-world', ['name' => 'Justin'])->html();
} elseif ($_instance->childHasBeenRendered('pKEZjZQ')) {
    $componentId = $_instance->getRenderedChildComponentId('pKEZjZQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('pKEZjZQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pKEZjZQ');
} else {
    $response = \Livewire\Livewire::mount('hello-world', ['name' => 'Justin']);
    $html = $response->html();
    $_instance->logRenderedChild('pKEZjZQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> -->

    <div class="flex mx-10 my-5 flex-center position-ref full-height">
        
        <div class="w-1/3">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('stripe-payment-intent')->html();
} elseif ($_instance->childHasBeenRendered('FE37Y4m')) {
    $componentId = $_instance->getRenderedChildComponentId('FE37Y4m');
    $componentTag = $_instance->getRenderedChildComponentTagName('FE37Y4m');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FE37Y4m');
} else {
    $response = \Livewire\Livewire::mount('stripe-payment-intent');
    $html = $response->html();
    $_instance->logRenderedChild('FE37Y4m', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>


        <div class="w-1/3">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('payment-intent-confirm')->html();
} elseif ($_instance->childHasBeenRendered('jeZZEjK')) {
    $componentId = $_instance->getRenderedChildComponentId('jeZZEjK');
    $componentTag = $_instance->getRenderedChildComponentTagName('jeZZEjK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jeZZEjK');
} else {
    $response = \Livewire\Livewire::mount('payment-intent-confirm');
    $html = $response->html();
    $_instance->logRenderedChild('jeZZEjK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>


        <div class="w-1/3">
    
        </div>
    </div>


    <!-- these are the components - end -->

    <div class="block h-5 "></div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout-stripe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\jade\livewire_hpp\resources\views/stripe.blade.php ENDPATH**/ ?>