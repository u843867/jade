<div>

    <input wire:model="name" type="text">
    
    Hello <?php echo e($name); ?>


</div>
<?php /**PATH D:\xampp\htdocs\jade\livewire_hpp\resources\views/livewire/hello-world.blade.php ENDPATH**/ ?>