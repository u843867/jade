<html>
    <head>

        <title>Laravel</title>
      
        <?php echo \Livewire\Livewire::styles(); ?>

        
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"
    </head>

    <body>

        <p class="text-xl">I'm a paragraphsda</p>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hello-world', ['name' => 'Jkustin'])->html();
} elseif ($_instance->childHasBeenRendered('LiZgP5a')) {
    $componentId = $_instance->getRenderedChildComponentId('LiZgP5a');
    $componentTag = $_instance->getRenderedChildComponentTagName('LiZgP5a');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LiZgP5a');
} else {
    $response = \Livewire\Livewire::mount('hello-world', ['name' => 'Jkustin']);
    $html = $response->html();
    $_instance->logRenderedChild('LiZgP5a', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        
        <?php echo \Livewire\Livewire::scripts(); ?>


    </body>

</html>
<?php /**PATH D:\xampp\htdocs\jade\livewire_hpp\resources\views/welcome.blade.php ENDPATH**/ ?>