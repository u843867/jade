

<!-- This example requires Tailwind CSS v2.0+ -->
<div>
  <nav class="bg-gray-800">
    <div class="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
      <div class="flex items-center justify-between h-16">
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <img class="w-8 h-8" src="https://tailwindui.com/img/logos/workflow-mark-indigo-500.svg" alt="Workflow">
          </div>
          <h1 class="px-3 py-2 text-xl font-semibold tracking-tight text-white">Order Management</h1>
        </div>

      </div>
    </div>

  </nav>


</div>
<?php /**PATH D:\xampp\htdocs\jade\livewire_hpp\resources\views/order-header.blade.php ENDPATH**/ ?>