

<?php $__env->startSection('header'); ?>

    <?php echo $__env->make('simple-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main-content'); ?>
    
    
    <!-- livewire component - start -->

    <div class="flex mx-3 my-3 flex-center position-ref full-height">
        
        <div class="w-full">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order')->html();
} elseif ($_instance->childHasBeenRendered('4qICYh9')) {
    $componentId = $_instance->getRenderedChildComponentId('4qICYh9');
    $componentTag = $_instance->getRenderedChildComponentTagName('4qICYh9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4qICYh9');
} else {
    $response = \Livewire\Livewire::mount('order');
    $html = $response->html();
    $_instance->logRenderedChild('4qICYh9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
      
    </div>

    <!-- livewire component - end -->
    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\jade\livewire_hpp\resources\views/order.blade.php ENDPATH**/ ?>