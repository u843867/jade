

<?php $__env->startSection('hpp-header-content'); ?>

    <!-- this is the livewire header component -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hpp-header')->html();
} elseif ($_instance->childHasBeenRendered('0wA8y9v')) {
    $componentId = $_instance->getRenderedChildComponentId('0wA8y9v');
    $componentTag = $_instance->getRenderedChildComponentTagName('0wA8y9v');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0wA8y9v');
} else {
    $response = \Livewire\Livewire::mount('hpp-header');
    $html = $response->html();
    $_instance->logRenderedChild('0wA8y9v', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    

    
    <!-- these are the components - start -->
    <!-- <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hello-world', ['name' => 'Justin'])->html();
} elseif ($_instance->childHasBeenRendered('jhpf8ta')) {
    $componentId = $_instance->getRenderedChildComponentId('jhpf8ta');
    $componentTag = $_instance->getRenderedChildComponentTagName('jhpf8ta');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jhpf8ta');
} else {
    $response = \Livewire\Livewire::mount('hello-world', ['name' => 'Justin']);
    $html = $response->html();
    $_instance->logRenderedChild('jhpf8ta', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> -->

    <div class="flex mx-3 my-3  flex-center position-ref full-height">
        
        <div class="w-full">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hpp',['order_array' => $order_array])->html();
} elseif ($_instance->childHasBeenRendered('hJicVUG')) {
    $componentId = $_instance->getRenderedChildComponentId('hJicVUG');
    $componentTag = $_instance->getRenderedChildComponentTagName('hJicVUG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hJicVUG');
} else {
    $response = \Livewire\Livewire::mount('hpp',['order_array' => $order_array]);
    $html = $response->html();
    $_instance->logRenderedChild('hJicVUG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
      
    </div>


    <!-- these are the components - end -->

    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout-hpp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\jade\livewire_hpp\resources\views/hpp.blade.php ENDPATH**/ ?>