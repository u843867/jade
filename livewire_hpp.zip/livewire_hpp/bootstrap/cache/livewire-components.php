<?php return array (
  'hello-world' => 'App\\Http\\Livewire\\HelloWorld',
  'hpp' => 'App\\Http\\Livewire\\Hpp',
  'hpp-header' => 'App\\Http\\Livewire\\HppHeader',
  'oms' => 'App\\Http\\Livewire\\Oms',
  'order' => 'App\\Http\\Livewire\\Order',
  'order-index' => 'App\\Http\\Livewire\\OrderIndex',
  'order-show' => 'App\\Http\\Livewire\\OrderShow',
  'payment-authorisation' => 'App\\Http\\Livewire\\PaymentAuthorisation',
  'payment-initialise' => 'App\\Http\\Livewire\\PaymentInitialise',
  'payment-intent-confirm' => 'App\\Http\\Livewire\\PaymentIntentConfirm',
  'payment-route' => 'App\\Http\\Livewire\\PaymentRoute',
  'stripe-payment-intent' => 'App\\Http\\Livewire\\StripePaymentIntent',
);